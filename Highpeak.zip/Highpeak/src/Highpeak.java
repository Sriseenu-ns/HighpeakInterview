import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Highpeak
{

	static int minDiff(List<Integer> Prices, int N, int M)
	{
		int result = Integer.MAX_VALUE;
		Collections.sort(Prices);   
		
		for (int i=0; i<= N-M;i++)
			result = Math.min(result, Prices.get(i + M - 1) - Prices.get(i));
		return result;
	}

	static int findelements(int res,List<Integer> Prices, int N, int M)
	{
		int result = Integer.MAX_VALUE;
		for(int i=0; i<=N; i++)
		{
			result = Math.min(result, Prices.get(i + M - 1) - Prices.get(i));
			if (res==result)
				return i;
		}
		return 0;
	}

	public static void main(String[] args) 
	{

		List<String> OutputLines=new ArrayList<String>();
		//Reads the input file data
		File file = new File("D:\\Testinput.txt");
		List<String> Input=new ArrayList<String>();  
		
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e1) {
		
			e1.printStackTrace();
		}
		  
		String ip;
		try 
		{
			while ((ip = br.readLine()) != null)
			    Input.add(ip);//Input lines are added into a list
		} catch (IOException e) 		
		{
			e.printStackTrace();
		}
		
		List<String> Items = new ArrayList<String>();
		List<Integer> Prices = new ArrayList<Integer>();
		
		Map<String, Integer> ItemToPrice = new HashMap<>();
		for(int i=2;i<Input.size();i++)
		{
			//Good and price are added into a map of key value pair
			ItemToPrice.put(Input.get(i).split(":")[0].trim(),Integer.parseInt(Input.get(i).split(":")[1].trim()));
			//Prices alone are stored separately in a list for calculations
			Prices.add(Integer.parseInt(Input.get(i).split(":")[1].trim()));
		}
				
		//Map is sorted and stored in a linkedhashmap to preserve the order
		Map<String, Integer> ItemToPriceSortedByValue = ItemToPrice .entrySet() .stream() .sorted(Map.Entry.<String, Integer> comparingByValue()) .collect( Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
		
		//This holds the Number of employees	
		int M=Integer.parseInt(Input.get(0).split(":")[1].trim());
	
		int result=minDiff(Prices, Prices.size(), M);
		
		OutputLines.add("Number of the employees: "+M);
		OutputLines.add("\n");
		
		
		int startindex=findelements(result,Prices,Prices.size(),M);
		
		OutputLines.add("Here the goodies that are selected for distribution are:");
		//Iterating the linkedhashmap with found list of items.
		Set<String> KeySet = ItemToPriceSortedByValue.keySet();         	
		String[] keyArray = KeySet.toArray( new String[ KeySet.size() ] );
        for (int i=startindex;i<startindex+M;i++) 
        {
        	OutputLines.add(keyArray[i] + " : "+ ItemToPriceSortedByValue.get(keyArray[i]));
        
        }
		

    	OutputLines.add("\n");
		OutputLines.add("And the difference between the chosen goodies with highest price and the lowest price is "+result);		
		
    	//Write the output to a text file 
		try
		{    
	           FileWriter fw=new FileWriter("D:\\Testoutput.txt"); 
	           for(String s:OutputLines)
	           {
	        	   fw.write(s+"\n");	        	  
	           }
	           fw.close();    
	    }
		catch(Exception e)
		{
			e.printStackTrace();	
		}    
	                  
	}
}